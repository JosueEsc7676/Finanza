package Com.Finanzas.FinanzeApp.controladores;

import Com.Finanzas.FinanzeApp.modelos.Usuario;
import Com.Finanzas.FinanzeApp.repositorios.UsuarioRepositorio;
import Com.Finanzas.FinanzeApp.servicios.interfaces.UsuarioServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller; // <-- ESTA LÍNEA
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import java.security.Principal;
import java.util.Map;
import java.util.Optional;

@Controller // <-- AGREGA ESTA ANOTACIÓN AQUÍ
public class ConfiguracionController {

    @Autowired
    private UsuarioServicio usuarioServicio;

    @Autowired
    private UsuarioRepositorio usuarioRepositorio;

    @GetMapping("/configuracion")
    public String mostrarConfiguracion() {
        return "configuracion"; // Este debe coincidir con templates/configuracion.html
    }

    @PostMapping("/usuario/tema")
    @ResponseBody
    public ResponseEntity<?> actualizarTema(@RequestBody Map<String, String> datos, Principal principal) {
        String nuevoTema = datos.get("tema");
        Optional<Usuario> optionalUsuario = usuarioRepositorio.findByCorreo(principal.getName());

        if (optionalUsuario.isEmpty()) {
            return ResponseEntity.status(404).body("Usuario no encontrado");
        }

        Usuario usuario = optionalUsuario.get();
        usuario.setTema(nuevoTema);
        usuarioRepositorio.save(usuario);

        return ResponseEntity.ok().build();
    }
}
