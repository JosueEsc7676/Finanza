package Com.Finanzas.FinanzeApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinanzeAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
