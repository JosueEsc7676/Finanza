package Com.Finanzas.FinanzeApp.repositorios;

import Com.Finanzas.FinanzeApp.modelos.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface CategoriaRepository extends JpaRepository<Categoria, Long> {
    List<Categoria> findByTipo(String tipo);


        List<Categoria> findByUsuarioId(Long usuarioId);
        List<Categoria> findByUsuarioIdAndTipo(Long usuarioId, String tipo);
    }


