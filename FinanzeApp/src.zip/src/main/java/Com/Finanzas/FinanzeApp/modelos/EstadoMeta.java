package Com.Finanzas.FinanzeApp.modelos;

public enum EstadoMeta {
    PENDIENTE,
    EN_PROGRESO,
    COMPLETADA,
    VENCIDA
}
